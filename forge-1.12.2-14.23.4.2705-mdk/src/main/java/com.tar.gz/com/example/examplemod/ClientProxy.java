package com.example.examplemod;

import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

public class ClientProxy extends ServerProxy{
	
	public void preInit(FMLPreInitializationEvent event){
	}
	

}
