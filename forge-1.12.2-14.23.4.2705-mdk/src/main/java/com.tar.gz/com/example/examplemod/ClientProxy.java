package com.example.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelSkeleton;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderFireball;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderSkeleton;
import net.minecraft.client.renderer.entity.RenderSnowball;
import net.minecraft.entity.Entity;
import net.minecraftforge.fml.client.registry.IRenderFactory;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

public class ClientProxy extends ServerProxy{
	
	public void preInit(FMLPreInitializationEvent event){
		

		
//		Sample Rendering entry using new RenderFactory method
//		RenderingRegistry.registerEntityRenderingHandler(Entity[entity].class, new IRenderFactory() {
//
//			@Override
//			public Render<? super Entity[entity> createRenderFor(RenderManager manager) {
//				System.out.println("creating renderer");
//				return new Render[entity](manager, new Model[entity](), 1.0F);
//			}
//		});
		
		//alternate call using Renderer Llamda
//  	registerEntityRenderingHandler(MyEntity.class, MyRenderer::new)
		
//		RenderingRegistry.registerEntityRenderingHandler(TestEntity.class, RenderTestEntity::new);

		RenderingRegistry.registerEntityRenderingHandler(TestEntity.class, new IRenderFactory<TestEntity>() {

			@Override
			public Render<TestEntity> createRenderFor(RenderManager manager) 
			{
				System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>> creating renderer");
				return new RenderTestEntity(Minecraft.getMinecraft().getRenderManager(), 1.0F);
			}
			
			
		});		
		
		
	}
	

}
