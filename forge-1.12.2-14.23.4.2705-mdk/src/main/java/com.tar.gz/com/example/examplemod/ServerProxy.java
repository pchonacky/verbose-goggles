package com.example.examplemod;

import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

public class ServerProxy {
	public void preInit(FMLPreInitializationEvent event){}
}
