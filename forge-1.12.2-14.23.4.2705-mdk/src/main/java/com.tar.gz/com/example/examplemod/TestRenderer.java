package com.example.examplemod;

import net.minecraft.client.renderer.entity.RenderFireball;
import net.minecraft.client.renderer.entity.RenderManager;

public class TestRenderer extends RenderFireball {

	public TestRenderer(RenderManager renderManagerIn, float scaleIn) {
		super(renderManagerIn, scaleIn);
	
	}

}
